public class Main {
    public static void main(String[] args) {
        QueryPage nQueryPage = new QueryPage();
        //LoginPage nLoginPage = new LoginPage();
    }
}




